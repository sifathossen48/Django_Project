from django.db import models

# Create your models here.
class User(models.Model):
    user_name = models.CharField(max_length=100)
    profile_picture = models.ImageField(upload_to='profile_picture/')
    twitter = models.CharField(max_length=100)
    facebook = models.CharField(max_length=100)
    instagram = models.CharField(max_length=100)
    skype = models.CharField(max_length=100)
    linkedin = models.CharField(max_length=100)

    def __str__(self):
        return self.user_name

class Text(models.Model):
    specialist = models.CharField(max_length=50)

    def __str__(self):
        return self.specialist

class About(models.Model):
    main_desc = models.CharField(max_length=200)
    about_image = models.ImageField(upload_to='about/')
    title = models.CharField(max_length=100)
    about_desc = models.TextField(max_length=200)
    about_desc2 = models.TextField(max_length=350)
    birthday = models.DateField()
    age = models.IntegerField()
    degree = models.CharField(max_length=20)
    website = models.CharField(max_length=100)
    phone = models.IntegerField()
    email = models.EmailField(max_length=80)
    city = models.CharField(max_length=50)
    freelance = models.CharField(max_length=40)

    def __str__(self):
        return self.title

class Fact(models.Model):
    describe = models.TextField(max_length=350)
    clients_no = models.IntegerField()
    clients_desc = models.CharField(max_length=30)
    clients_sub_desc = models.CharField(max_length=50)
    project_no = models.IntegerField()
    project_desc = models.CharField(max_length=30)
    project_sub_desc = models.CharField(max_length=50)
    working_hours = models.IntegerField()
    working_hours_desc = models.CharField(max_length=30)
    working_hours_sub_desc = models.CharField(max_length=50)
    workers_no = models.IntegerField()
    workers_desc = models.CharField(max_length=30)
    workers_sub_desc = models.CharField(max_length=50)

    def __str__(self):
        return self.describe

class Skill(models.Model):
    skill_name = models.CharField(max_length=20)
    percentage = models.IntegerField()

    def __str__(self):
        return self.skill_name

class Description(models.Model):

    skill_desc = models.TextField(max_length=350)
    resume_desc = models.TextField(max_length=350)
    portfolio_desc = models.TextField(max_length=350)
    services_desc = models.TextField(max_length=350)
    testimonials_desc = models.TextField(max_length=350)
    contact_desc = models.TextField(max_length=300)

    def __str__(self):
        return self.resume_desc


class PortfolioApps(models.Model):
    name = models.CharField(max_length=40)
    image = models.ImageField(upload_to='portfolio/')

    def __str__(self):
        return self.name

class PortfolioCards(models.Model):
    name = models.CharField(max_length=40)
    image = models.ImageField(upload_to='portfolio/')

    def __str__(self):
        return self.name

class PortfolioWeb(models.Model):
    name = models.CharField(max_length=40)
    image = models.ImageField(upload_to='portfolio/')

    def __str__(self):
        return self.name


class Service(models.Model):
    image = models.ImageField(upload_to='service/')
    title = models.CharField(max_length=20)
    describe = models.TextField(max_length=250)

    def __str__(self):
        return self.title


class Testimonial(models.Model):
    describe = models.TextField(max_length=150)
    image = models.ImageField(upload_to='testimonial/')
    name = models.CharField(max_length=20)
    title = models.CharField(max_length=20)

    def __str__(self):
        return self.name

class Favicon(models.Model):
    image = models.ImageField(upload_to='favicon/')


class Contact(models.Model):
    name = models.CharField(max_length=25)
    email = models.EmailField(max_length=25)
    subject = models.CharField(max_length=25)
    message = models.TextField(max_length=300)

    def __str__(self):
        return self.name

class Copyright(models.Model):
    site = models.CharField(max_length=20)
    designer = models.CharField(max_length=20)
    designer_profile_link = models.CharField(max_length=100)

    def __str__(self):
        return self.site





