from django.contrib import admin

from iPortfolio.models import User, Text, About, Fact, Skill, Description, Service, Testimonial, PortfolioApps, \
    PortfolioCards, PortfolioWeb, Favicon, Contact, Copyright

# Register your models here.
admin.site.register(User)
admin.site.register(Text)
admin.site.register(About)
admin.site.register(Fact)
admin.site.register(Skill)
admin.site.register(Description)
admin.site.register(Service)
admin.site.register(Testimonial)
admin.site.register(PortfolioApps)
admin.site.register(PortfolioCards)
admin.site.register(PortfolioWeb)
admin.site.register(Favicon)
admin.site.register(Contact)
admin.site.register(Copyright)
